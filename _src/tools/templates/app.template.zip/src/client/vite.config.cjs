module.exports = {
	root: '',
	build: {
		outDir: '../../dist/client'
	},
	server: {
		port: '5173'
	}
}