import { Nanium } from 'nanium/core';
import { LogLevel } from 'nanium/interfaces/logger';
import { NaniumConsumerBrowserHttp } from 'nanium/managers/consumers/browserHttp';
import { Echo } from '../../server/services/echo.contractpart';
import { EchoRequest } from '../../server/services/echo.contract';
import './style.css';


async function init() {
  let serverBaseUrl: string = '';
  if (location.port === '5173') {
    serverBaseUrl = 'http://' + location.host.replace(':5173', ':3000');
    Nanium.logger.loglevel = LogLevel.info;
  }

  await Nanium.addManager(new NaniumConsumerBrowserHttp({
    apiUrl: serverBaseUrl + '/services',
    apiEventUrl: serverBaseUrl + '/events',
  }));

  new EchoRequest({ text: 'hello' }).execute().then((echo: Echo) => {
      const div = document.createElement('div');
      div.innerHTML = echo.text ?? '';
      document.getElementById('echo')?.appendChild(div);
  });
}

init();
