export const appConfig = {
	port: 3000,
	workerCount: undefined,
};