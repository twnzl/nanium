import { NaniumObject, RequestType, Type } from 'nanium/objects';
import { Echo } from './echo.contractpart';
import { ServiceRequestBase } from './serviceRequestBase';

export class EchoRequestBody extends NaniumObject<EchoRequestBody> {
	@Type(String) text?: string;
}

@RequestType({
	responseType: Echo,
	genericTypes: { TRequestBody: EchoRequestBody },
	scope: 'public'
})
export class EchoRequest extends ServiceRequestBase<EchoRequestBody, Echo> {
	static serviceName: string = 'MyApp:echo';
}
