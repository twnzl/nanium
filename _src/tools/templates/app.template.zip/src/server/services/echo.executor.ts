import { ServiceExecutor } from 'nanium/interfaces/serviceExecutor';
import { EchoRequest } from './echo.contract';
import { Echo } from './echo.contractpart';
import { ServiceRequestContext } from './serviceRequestContext';

export class EchoExecutor implements ServiceExecutor<EchoRequest, Echo> {
	static serviceName: string = 'MyApp:echo';

	async execute(request: EchoRequest, executionContext: ServiceRequestContext): Promise<Echo> {		
		return new Echo({ text: request.body.text });
	}
}
