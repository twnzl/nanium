import { NaniumObject, Type } from 'nanium/objects';

export class Echo extends NaniumObject<Echo> {
	@Type(String) text?: string;
}
