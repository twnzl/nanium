import cluster from 'cluster';
import { ClusterCommunicator } from 'nanium/communicators/clusterCommunicator';
import { Nanium } from 'nanium/core';
import { NaniumHttpChannel } from 'nanium/managers/providers/channels/http';
import { NaniumProviderNodejs } from 'nanium/managers/providers/nodejs';
import * as fs from 'node:fs';
import * as http from 'node:http';
import { IncomingMessage, ServerResponse } from 'node:http';
import path from 'node:path';
import 'source-map-support/register';
import { appConfig } from './app-config';
import { ServiceRequestContext } from './services/serviceRequestContext';

let coreResolve: Function;


// for workers or single process
async function runNormalProcess() {
	// init http server
	const server = http.createServer(async (req: IncomingMessage, res: ServerResponse) => {

		//#region CORS
		if (req.headers.origin?.startsWith('http://localhost:') && req.headers.host === ('localhost:3000')) {
			res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
			res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
			res.setHeader('AMP-Access-Control-Allow-Source-Origin', req.headers.origin);
		}
		if (req.method === 'OPTIONS') {
			res.statusCode = 200;
			res.end();
			return;
		}
		//#endregion CORS

		//#region provide client as static files

		if (!req.url?.startsWith('/services/') && !req.url?.startsWith('/events/')) {
			let url = req.url ?? '';
			if ((url || '/') === '/') {
				url = 'index.html';
			}
			if (url?.endsWith('.js')) {
				res.setHeader('Content-Type', 'text/javascript');
			} else if (url?.endsWith('.css')) {
				res.setHeader('Content-Type', 'text/css');
			}
			fs.readFile(path.join(__dirname, '..', 'client', url ?? ''), (err, data) => {
				if (err) {
					res.writeHead(404);
					res.end(JSON.stringify(err));
					return;
				}
				res.writeHead(200);
				res.end(data);
			});
			return;
		}
		//#endregion provide client as static files		
	});

	// start the http server
	server.listen(appConfig.port);

	// init nanium API
	await Nanium.addManager(new NaniumProviderNodejs({
		servicePath: 'services',
		channels: [
			new NaniumHttpChannel('1', { apiPath: '/services', eventPath: '/events', server: server, /* useCompression: true */ }),
		],
		// eventSubscriptionReceiveInterceptors: [AuthenticationInterceptor],
		// eventEmissionSendInterceptors: [EventEmissionSendInterceptor]
	}));

	// nanium communicators
	Nanium.communicators = [new ClusterCommunicator(ServiceRequestContext.toTransferableContext, ServiceRequestContext.fromTransferableContext )];
	
	console.log('ready');
}


// for primary process in a multi process setup
async function runPrimaryProcess() {
}


// exception handling
function handleError(err: any) {
	console.error(err);
}
process.on('unhandledRejection', handleError);
process.on('uncaughtException', handleError);


// signal handling
let shutdownInProgress: boolean = false;
async function handleEndSignals() {
	if (cluster.isPrimary) {
		const workers = Object.values(cluster.workers ?? {});
		if (workers.length === 0) {
			if (!shutdownInProgress) {
				shutdownInProgress = true;
				await Nanium.shutdown();
				process.exit(0);
			}
		} else {
			process.on('WORKER_SHUT_DOWN', () => {
				setTimeout(() => {
					if (!Object.values(cluster.workers ?? {}).length) {
						process.exit();
					}
				}, 100);
			});
			for (const worker of workers) {
				worker?.send('SIGTERM');
			}
		}
	} else if (cluster.isWorker) {
		if (!shutdownInProgress) {
			shutdownInProgress = true;
			await Nanium.shutdown();
			process.send!('WORKER_SHUT_DOWN');
			process.exit(0);
		}
	}
}
process.on('SIGTERM', handleEndSignals);
process.on('SIGINT', handleEndSignals);


// start
(async function () {
	if (cluster.isPrimary && (appConfig.workerCount ?? 1) > 1) {
		await runPrimaryProcess();
	} else {
		await runNormalProcess();
	}
})().then();
